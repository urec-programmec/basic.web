<template>
    <form @submit.prevent="onSubmit">
        <input type="text" v-model="size">
        <button type="submit">Change size</button>
    </form>
</template>

<script>
    export default {
        data() {
            return {
                size: 0
            }
        },
        methods: {
            onSubmit(){
                // console.log('Submit ', typeof this.size);
                let size = parseInt(this.size)
                this.size = ""
                if (Number.isInteger(size) && size > 0 && size <= 200) {
                    // console.log('Submit ', this.size);
                    const newSize = {
                        id: Date.now(),
                        size: size,
                    }
                    this.size = size
                    this.$emit("change-size", newSize)
                }

            }
        },
    }
</script>

<style scoped>
    form {
        display: flex;
    }

    input{
        width: 100px;
    }
</style>