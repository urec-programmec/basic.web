<template>
    <div>
        <div class="menu">
            <SizeController
                @change-size="changeSize"
            />
            <CountController v-bind:isRunning="isRunning"
                @change-count="changeCount"
            />
            <SpeedController
                @change-speed="changeSpeed"
            />
        </div>
        <hr>
        <div class="menu">
            <strong>Size: {{this.blocks[0].size}}px</strong>
            <strong>Count: {{Math.sqrt(this.blocks.length)}} blocks per line</strong>
            <strong>Speed: {{5000 / this.speed}} step per second</strong>
        </div>
        <hr>
        <!--+ (0.1 * 2 * Math.sqrt(blocks.length) - 1)-->
        <div class="desk"
             v-bind:style="{height: (Math.sqrt(blocks.length) * blocks[0].size) + 'px', width: (Math.sqrt(blocks.length) * blocks[0].size) + 'px'}">
            <Block
                v-for="block in blocks"
                v-bind:properties="block"
                v-bind:key="block.id"
            />
        </div>
        <hr>
        <div class="menu">
            <strong>Score: {{score}} points</strong>
            <strong>Max score: {{max}} points</strong>
        </div>
        <hr>
        <button @click="Start" id="clickme">{{btnText}}</button>
        <button @click="Reset" id="reset">Reset</button>
    </div>
</template>

<script>
import Block from "@/components/Block"
import SizeController from "@/components/SizeController"
import CountController from "@/components/CountController"
import SpeedController from "@/components/SpeedController"

export default {
    created() {
        document.addEventListener('keydown', this.changeDirection)
        this.blocks = []
        let size = 18
        for (let i = 0; i < size * size; i++){
            this.blocks.push({id: i + 1, isSnake: false, isBlock: true, isFood: false, isSnakeTail: false, isSnakeHead: false, next: -1, size: 25},)
        }

        this.blocks[parseInt(size * (size / 2 + 0.5))].isBlock = false
        this.blocks[parseInt(size * (size / 2 + 0.5))].isSnake = true
        this.blocks[parseInt(size * (size / 2 + 0.5))].isSnakeHead = true
        this.blocks[parseInt(size * (size / 2 + 0.5))].isSnakeTail = true
        this.blocks[parseInt(size * (size / 2 + 0.5))].next = this.blocks[parseInt(size * (size / 2 + 0.5))].id

        let rand1 = parseInt(Math.random() * size / 2)
        let rand2 = parseInt(Math.random() * size / 2)
        while (this.blocks[rand1 + rand2].isSnake){
            rand1 = parseInt(Math.random() * size)
            rand2 = parseInt(Math.random() * size)
        }
        this.blocks[rand1 + rand2].isBlock = false
        this.blocks[rand1 + rand2].isFood = true

        this.max = document.cookie.substring(4)
    },

    beforeDestroy() {
        document.removeEventListener('keydown', this.changeDirection)
    },
    components: {
        Block,
        SizeController,
        CountController,
        SpeedController,
    },
    data() {
        return {
            blocks: [],
            speed: 80,
            direction: "up",
            isRunning: false,
            timer: null,
            isChanged: false,
            score: 0,
            max: 0,
        }
    },
    methods:{
        changeSize(newSize){
            // console.log(this.blocks.length)

            for (let i = 0; i < this.blocks.length; i++){
                this.blocks[i].size = newSize.size;
                this.blocks[i].size = newSize.size;
            }
        },
        changeCount(newCount){
            let nowLen = Math.sqrt(this.blocks.length)

            if(newCount.count > nowLen){
                for (let i = this.blocks.length; i < newCount.count * newCount.count; i++)
                    this.blocks.push({
                        id: this.blocks[this.blocks.length - 1].id + 1,
                        isSnake: false,
                        isBlock: true,
                        isFood: false,
                        isSnakeBody: false,
                        isSnakeHead: false,
                        size: this.blocks[0].size
                    },)
            }
            else {
                let countDelete = 0
                let diff = nowLen - newCount.count
                // console.log(diff)
                while (diff > 0) {

                    let len = this.blocks.length - nowLen

                    for (let i = 0; i < len; i+= nowLen) {
                        if (this.blocks[i].isBlock){
                            this.blocks.splice(i, 1)
                        }

                        else{
                            countDelete += 1
                        }
                    }


                    len = this.blocks.length - 1;

                    for (let i = len - nowLen; i < len; i++) {
                        if (this.blocks[len - nowLen].isBlock)
                            this.blocks.splice(len - nowLen, 1)
                        else {
                            countDelete += 1
                        }
                    }

                    len = this.blocks.length - 1
                    while (countDelete > 0){
                        if (this.blocks[len].isBlock){
                            this.blocks.splice(len, 1)
                            countDelete --
                        }
                        len--
                    }

                    diff -= 1;
                    nowLen -= 1
                }

            }
        },
        changeSpeed(newSpeed){
            this.speed = newSpeed.speed
        },
        Start(){
            this.isRunning = !this.isRunning
            if (this.isRunning)
                this.Running()
            else
                clearTimeout(this.timer)

        },
        Running(){
            this.isChanged = false
            if (!parseInt(this.score))
                this.score = 0


            let index = this.blocks.indexOf(this.blocks.filter(i => i.isSnakeHead)[0])
            let newIndex = -1
            let size = Math.sqrt(this.blocks.length)

            switch (this.direction){
                case "up":
                    newIndex = index >= size ? index - size : index + size * (size - 1)
                    break;
                case "down":
                    newIndex = index < size * (size - 1) ? index + size : index - size * (size - 1)
                    break;
                case "left":
                    newIndex = (index % size == 0) ? index + size - 1 : index - 1
                    break;
                case "right":
                    newIndex = ((index + 1) % size == 0) ? index - size + 1 : index + 1
                    break;
            }

            // ход

            if(this.blocks[newIndex].isSnake){
                let score = this.score
                document.getElementById("reset").click()
                this.score = "You died! Final score was " + score
                if (score > this.max){
                    this.max = score
                    document.cookie = "max=" + this.max+ "; max-age=3600";
                }
                return
            }

            // let isSnake = this.blocks[newIndex].isSnake

            this.blocks[index].isSnakeHead = false
            this.blocks[index].next = this.blocks[newIndex].id
            this.blocks[newIndex].isBlock = false
            this.blocks[newIndex].isSnake = true
            this.blocks[newIndex].isSnakeHead = true

            if(!this.blocks[newIndex].isFood){
                let tail = this.blocks.indexOf(this.blocks.filter(i => i.isSnakeTail)[0])

                this.blocks[tail].isSnake = false
                this.blocks[tail].isSnakeTail = false
                this.blocks[tail].isBlock = true

                // console.log(this.blocks.filter(i => i.next == this.blocks[tail].next)[0])

                this.blocks.filter(i => i.id === this.blocks.filter(i => i.next == this.blocks[tail].next)[0].next)[0].isSnakeTail = true

            }
            else {
                this.blocks[newIndex].isFood = false
                let temp = this.blocks.filter(i=>i.isBlock)
                index = parseInt(Math.random() * temp.length, 10)
                temp[index].isFood = true
                temp[index].isBlock = false
                this.score++

            }

            // console.log("***")
            // console.log(this.blocks.indexOf(this.blocks.filter(i => i.isSnakeHead)[0]))
            // console.log(this.blocks.indexOf(this.blocks.filter(i => i.isSnakeTail)[0]))
            // console.log("---")

            this.timer = setTimeout(this.Running, 5000 / this.speed)
        },
        Reset(){
            if (this.isRunning)
                document.getElementById("clickme").click()
            this.score = 0
            for(let i = 0; i < this.blocks.length; i++){
                this.blocks[i].isSnake = this.blocks[i].isSnakeHead
                this.blocks[i].isSnakeTail = this.blocks[i].isSnake
                this.blocks[i].isBlock = this.blocks[i].isSnake ? false : (this.blocks[i].isFood ? false : true)
            }
        },
        changeDirection: function(e) {
            let dir = ""

            if (e.keyCode === 32)
                document.getElementById("clickme").click()

            if (e.keyCode === 37 && this.direction != "right" && this.direction != "left") {
                dir = "left"
            } else if (e.keyCode === 38 && this.direction != "down" && this.direction != "up") {
                dir = "up"
            } else if (e.keyCode === 39 && this.direction != "left" && this.direction != "right") {
                dir = "right"
            } else if (e.keyCode === 40 && this.direction != "up" && this.direction != "down") {
                dir = "down"
            }

            if (dir != "" && !this.isChanged){
                this.isChanged = true
                this.direction = dir
                // console.log(this.direction)
            }

        },
    },
    computed: {
        btnText: function() {
            if(!this.isRunning) {
                return 'Start'
            }

            return 'Stop'
        }
    }
}

</script>

<style scoped>
    .desk {
        display: flex;
        justify-content: center;
        align-items: center;
        flex-direction: row;
        flex-wrap: wrap;
        border: 2px solid black;
        margin: auto;
    }

    .menu {
        display: flex;
        flex-direction: row;
        justify-content: space-around;
    }

    button {
        margin: 10px;
    }
</style>