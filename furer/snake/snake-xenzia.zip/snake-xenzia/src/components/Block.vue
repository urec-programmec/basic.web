<template>
    <div
        v-bind:class="{snake: properties.isSnake, food: properties.isFood, block: properties.isBlock, head: properties.isSnakeHead, tail: properties.isSnakeTail}"
        v-bind:style="{height: properties.size + 'px', width: properties.size + 'px', background: properties.isBlock ? 'white' : (properties.isFood ? 'green' : '#' + (Math.random().toString(16) + '000000').substring(2,8).toUpperCase())}">
    </div>
</template>

<script>
    export default {
        props: {
            properties: {
                type: Object,
                required: true
            },
        },

    }
</script>

<style scoped>
    .snake {
        background: black;
    }

    .food {
        background: green;
        border-radius: 50%;
    }

    .block {
        background: white;
    }

    .head {
        /*background: darkred;*/
    }

    .tail {
        /*border-radius: 50%;*/
    }

    div {
        /*border: 0.1px solid black;*/
    }

</style>