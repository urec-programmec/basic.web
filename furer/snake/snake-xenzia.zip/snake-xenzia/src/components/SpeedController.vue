<template>
    <form @submit.prevent="onSubmit">
        <input type="text" v-model="speed">
        <button type="submit">Change speed</button>
    </form>
</template>

<script>
    export default {
        data() {
            return {
                speed: 0
            }
        },
        methods: {
            onSubmit(){
                let speed = parseInt(this.speed);
                this.speed = ""
                if (Number.isInteger(speed) && speed > 0 && speed <= 200) {
                    const newSpeed = {
                        id: Date.now(),
                        speed: speed,
                    }
                    this.speed = speed
                    this.$emit("change-speed", newSpeed)
                }
            }
        },
    }
</script>

<style scoped>
    form {
        display: flex;
    }

    input{
        width: 100px;
    }
</style>