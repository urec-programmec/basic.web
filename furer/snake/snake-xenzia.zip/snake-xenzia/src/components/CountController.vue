<template>
    <form @submit.prevent="onSubmit">
        <input type="text" v-model="count">
        <button type="submit">Change count</button>
    </form>
</template>

<script>
    //:disabled="isRunning"

    export default {
        data() {
            return {
                count: 0
            }
        },
        props: {
            isRunning: {
                type: Boolean,
                required: true
            },
        },
        methods: {
            onSubmit(){
                let count = parseInt(this.count);
                this.count = ""
                if (Number.isInteger(count) && count >= 5 && count <= 100) {
                    const newCount = {
                        id: Date.now(),
                        count: count,
                    }
                    this.count = count
                    this.$emit("change-count", newCount)
                }

            }
        },
    }
</script>

<style scoped>
    form {
        display: flex;
    }

    input{
        width: 100px;
    }
</style>